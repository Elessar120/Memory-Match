﻿using System;
using UnityEngine;

[Serializable] 
public class CardData
    {
        public int index;
        public Sprite cardFrontImage;
        public Sprite cardBackImage;
    }