﻿namespace Enum
{
    public enum GameState
    {
        WaitingForInput,
        ResolvingMatch,
        GameOver
    }
}