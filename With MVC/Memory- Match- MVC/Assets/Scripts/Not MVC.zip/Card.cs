using UnityEngine;
using UnityEngine.UI;
public class Card : MonoBehaviour
{
   public Image image;
   [HideInInspector] public Sprite sprite;
   [HideInInspector] public Sprite back;
   [HideInInspector] public int id;
}
